#!/usr/bin/env python3
"""Safe launcher for original Icefall finetune.py patched for Experiment C.

Modes:
  start   --init-checkpoint PATH --exp-dir PATH [--epochs N]
  resume  --exp-dir PATH [--checkpoint NAME_OR_PATH] [--epochs N]
  restart --checkpoint PATH --exp-dir NEW_PATH [--epochs N]
  status  --exp-dir PATH

Important: 'restart' loads MODEL WEIGHTS into a NEW run; 'resume' restores
optimizer/scheduler/scaler and the existing Icefall sampler checkpoint state.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import zipfile
from pathlib import Path

DEFAULT_EXP = "/mnt/d/Croko_Training/exp_4way_C_epoch6_pilot"
DEFAULT_TRAIN = "/mnt/d/Croko_Training/manifests/experiment_c_mix_120k.jsonl.gz"
DEFAULT_DEV = "/mnt/g/SAPC2_Dataset/manifests/sapc2_cuts_dev_small.jsonl.gz"
DEFAULT_INIT = "/mnt/g/SAPC2_Dataset/exp_finetune_causal/epoch-6.pt"
DEFAULT_TRAINER = "~/icefall/egs/librispeech/ASR/zipformer/finetune_4way.py"
DEFAULT_BPE = "/mnt/g/SAPC2_Dataset/Pretrained_Zipformer/model/data/lang_bpe_510/bpe.model"
EPOCH_RE = re.compile(r"epoch-(\d+)\.pt$")
BATCH_RE = re.compile(r"checkpoint-(\d+)\.pt$")


def resolve(path):
    return Path(path).expanduser().resolve()


def fingerprint(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return {"path": str(path), "size": path.stat().st_size, "sha256": h.hexdigest()}


def check_file(p: Path, label: str):
    if not p.is_file():
        raise ValueError(f"{label} not found: {p}")
    return p


def verify_ckpt(p: Path):
    check_file(p, "Checkpoint")
    if p.stat().st_size < 1024 * 1024:
        raise ValueError(f"Checkpoint suspiciously small: {p}")
    if not zipfile.is_zipfile(p):
        raise ValueError(f"Checkpoint is not a complete PyTorch zip archive: {p}")
    return p


def list_checkpoints(exp_dir):
    if not exp_dir.exists():
        return []
    files = [p for p in exp_dir.glob("*.pt") if EPOCH_RE.fullmatch(p.name) or BATCH_RE.fullmatch(p.name)]
    return sorted(files, key=lambda p: p.stat().st_mtime, reverse=True)


def choose_checkpoint(exp_dir: Path, name: str | None):
    if name:
        p = resolve(name) if "/" in name or name.startswith("~") else exp_dir / name
        if p.parent != exp_dir:
            raise ValueError("Resume checkpoint must be directly inside the same exp-dir; use restart for weights from another run")
        return verify_ckpt(p)
    candidates = list_checkpoints(exp_dir)
    for candidate in candidates:
        try:
            return verify_ckpt(candidate)
        except ValueError as e:
            print(f"WARN skipping incomplete checkpoint: {e}")
    raise ValueError(f"No valid epoch-N.pt or checkpoint-N.pt found inside {exp_dir}")


def common_options():
    # Defaults selected to match the user's causal recipe conservatively.
    return {
        "world-size": "1", "manifest-dir": "/mnt/g/SAPC2_Dataset/manifests",
        "on-the-fly-feats": "True", "max-duration": "120", "use-fp16": "True",
        "base-lr": "0.0005", "enable-musan": "False", "num-workers": "4",
        "causal": "True", "chunk-size": "16,32", "left-context-frames": "128,256",
        "save-every-n": "1000", "average-period": "200", "keep-last-k": "5",
        "seed": "42", "valid-interval": "3000", "bpe-model": DEFAULT_BPE,
    }


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="mode", required=True)
    for mode in ("start", "resume", "restart", "status"):
        a = sub.add_parser(mode)
        a.add_argument("--exp-dir", default=DEFAULT_EXP)
        if mode != "status":
            a.add_argument("--trainer", default=DEFAULT_TRAINER)
            a.add_argument("--epochs", type=int, default=None, help="Total target epochs in THIS Experiment C run")
            a.add_argument("--dry-run", action="store_true")
        if mode in ("start", "restart"):
            a.add_argument("--train-manifest", default=DEFAULT_TRAIN)
            a.add_argument("--valid-manifest", default=DEFAULT_DEV)
            a.add_argument("--base-lr", type=float, default=0.0005)
            a.add_argument("--max-duration", type=float, default=120)
            a.add_argument("--num-workers", type=int, default=4)
            a.add_argument("--chunk-size", default="16,32")
            a.add_argument("--left-context-frames", default="128,256")
            a.add_argument("--save-every-n", type=int, default=1000)
            a.add_argument("--average-period", type=int, default=200)
            a.add_argument("--seed", type=int, default=42)
            a.add_argument("--bpe-model", default=DEFAULT_BPE)
        if mode == "start":
            a.add_argument("--init-checkpoint", default=DEFAULT_INIT)
        if mode in ("resume", "restart"):
            a.add_argument("--checkpoint", default=None if mode == "resume" else "", help="For resume, select an epoch/checkpoint INSIDE exp-dir; for restart, any PyTorch weights checkpoint")
    return p.parse_args()


def main():
    args = parse_args()
    exp = resolve(args.exp_dir)
    configpath = exp / "experiment_c_run.json"
    if args.mode == "status":
        print("Run directory:", exp)
        if configpath.is_file():
            data = json.loads(configpath.read_text())
            print("Initial checkpoint:", data["init_checkpoint"])
            print("Training manifest:", data["train_manifest"]["path"])
            print("Target epochs:", data["epochs"])
        for p in list_checkpoints(exp)[:12]:
            print(p.name, f"{p.stat().st_size / (1024**2):.0f} MiB")
        return
    trainer = check_file(resolve(args.trainer), "Patched trainer")
    if args.mode == "resume":
        if not configpath.is_file():
            raise ValueError(f"Missing run configuration: {configpath}. Resume requires a run created by this launcher.")
        cfg = json.loads(configpath.read_text())
        if cfg["trainer"] != str(trainer):
            raise ValueError(f"Trainer path differs from original run: {cfg['trainer']}")
        for k in ("train_manifest", "valid_manifest"):
            cur = fingerprint(check_file(resolve(cfg[k]["path"]), k))
            if cur["sha256"] != cfg[k]["sha256"]:
                raise ValueError(f"{k} changed since the run started. Refusing unsafe resume.")
        ckpt = choose_checkpoint(exp, args.checkpoint)
        match_epoch = EPOCH_RE.fullmatch(ckpt.name)
        match_batch = BATCH_RE.fullmatch(ckpt.name)
        if match_epoch:
            start_epoch, start_batch = int(match_epoch.group(1)) + 1, 0
        elif match_batch:
            start_epoch, start_batch = 2, int(match_batch.group(1))
        else:
            raise ValueError(f"Unsupported resume checkpoint name: {ckpt.name}")
        epochs = args.epochs if args.epochs is not None else cfg["epochs"]
        if epochs < start_epoch and start_batch == 0:
            raise ValueError(f"Target epochs {epochs} is less than next epoch {start_epoch}. Specify --epochs {start_epoch} or larger.")
        flags = cfg["flags"]
        print("RESUME: full optimizer/scheduler restoration via Icefall", ckpt)
        print("Resume epoch argument:", start_epoch, "batch argument:", start_batch)
    else:
        if args.mode == "restart" and not args.checkpoint:
            raise ValueError("restart needs --checkpoint PATH")
        ckpt = verify_ckpt(resolve(args.init_checkpoint if args.mode == "start" else args.checkpoint))
        if configpath.exists() or list_checkpoints(exp):
            raise ValueError(f"Experiment already exists in {exp}; choose a NEW --exp-dir. Originals and old checkpoints are protected.")
        train = check_file(resolve(args.train_manifest), "Training manifest")
        valid = check_file(resolve(args.valid_manifest), "Validation manifest")
        bpe = check_file(resolve(args.bpe_model), "SentencePiece model")
        flags = common_options()
        if args.save_every_n < args.average_period:
            raise ValueError("--save-every-n must be >= --average-period (Icefall assertion)")
        flags.update({"base-lr": str(args.base_lr), "max-duration": str(args.max_duration), "num-workers": str(args.num_workers), "chunk-size": args.chunk_size, "left-context-frames": args.left_context_frames, "save-every-n": str(args.save_every_n), "average-period": str(args.average_period), "seed": str(args.seed), "bpe-model": str(bpe)})
        epochs = args.epochs if args.epochs is not None else 2
        if epochs < 1:
            raise ValueError("Total epochs must be positive")
        cfg = {"init_checkpoint": str(ckpt), "trainer": str(trainer), "train_manifest": fingerprint(train), "valid_manifest": fingerprint(valid), "epochs": epochs, "flags": flags}
        start_epoch, start_batch = 1, 0
        print(args.mode.upper(), "from model weights:", ckpt)
    if epochs < 1:
        raise ValueError("Invalid --epochs")
    cli = [sys.executable, "-u", str(trainer)]
    for k, value in flags.items():
        cli += ["--" + k, value]
    cli += ["--exp-dir", str(exp), "--num-epochs", str(epochs), "--start-epoch", str(start_epoch), "--start-batch", str(start_batch)]
    if args.mode in ("start", "restart"):
        cli += ["--do-finetune", "True", "--finetune-ckpt", str(ckpt)]
    else:
        cli += ["--do-finetune", "False"]
    env = dict(os.environ, FOURWAY_TRAIN_MANIFEST=cfg["train_manifest"]["path"], FOURWAY_VALID_MANIFEST=cfg["valid_manifest"]["path"])
    print("COMMAND:", " ".join(__import__("shlex").quote(x) for x in cli), flush=True)
    if args.dry_run:
        print("DRY RUN ONLY; no files written or GPU training launched")
        return
    exp.mkdir(parents=True, exist_ok=True)
    if args.mode != "resume":
        fd = os.open(configpath, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            json.dump(cfg, out, indent=2)
    elif args.epochs is not None and args.epochs != cfg["epochs"]:
        cfg["epochs"] = epochs
        configpath.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")
    rc = subprocess.call(cli, cwd=str(trainer.parent.parent), env=env)
    if rc:
        raise SystemExit(f"Icefall trainer stopped with exit status {rc}; use resume after inspecting log/checkpoints")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, FileNotFoundError, RuntimeError) as ex:
        raise SystemExit("ERROR: " + str(ex))
