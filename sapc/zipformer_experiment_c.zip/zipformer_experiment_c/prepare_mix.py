#!/usr/bin/env python3
"""Prepare an exact-quota, streaming-safe Lhotse CutSet JSONL manifest.

Weights are per-CUT counts, not duration. No audio is copied.
Only TORGO may be repeated, at most twice by default, with unique cut IDs.
"""
from __future__ import annotations

import argparse
import gzip
import json
import os
import random
import shutil
import tempfile
from pathlib import Path

DEFAULT_SOURCES = {
    "sapc2": "/mnt/g/SAPC2_Dataset/manifests/sapc2_cuts_train_local.jsonl.gz",
    "aug": "/mnt/d/Croko_Training/manifests/sapc2_aug_cuts_train.jsonl.gz",
    "croko": "/mnt/d/Croko_Training/manifests/croko_cuts_train.jsonl.gz",
    "torgo": "/mnt/d/Croko_Training/TORGO_lhotse/torgo_cuts_train.jsonl.gz",
}
DEFAULT_WEIGHTS = {"sapc2": 70, "aug": 20, "croko": 7, "torgo": 3}


def open_text(path: Path, mode: str = "rt"):
    return gzip.open(path, mode, encoding="utf-8") if str(path).endswith(".gz") else open(path, mode, encoding="utf-8")


def counts_by_weights(total: int, weights: dict[str, float]) -> dict[str, int]:
    if any(v <= 0 for v in weights.values()):
        raise ValueError("All four weights must be positive")
    denom = sum(weights.values())
    raw = {k: total * w / denom for k, w in weights.items()}
    quotas = {k: int(v) for k, v in raw.items()}
    for k in sorted(weights, key=lambda x: raw[x] - quotas[x], reverse=True)[:total-sum(quotas.values())]:
        quotas[k] += 1
    return quotas


def count_records(path: Path) -> int:
    if not path.is_file():
        raise FileNotFoundError(path)
    with open_text(path) as inp:
        return sum(bool(line.strip()) for line in inp)


def stage_source(src: Path, destination: Path, *, name: str, quota: int, available: int, max_repeat: int, seed: int) -> None:
    rng = random.Random(f"{seed}|{name}|sample")
    if quota > available * max_repeat:
        raise ValueError(f"{name}: quota {quota:,} exceeds {available:,} records x repeat cap {max_repeat}")
    unique = min(quota, available)
    selected = set(rng.sample(range(available), unique))
    repeats_needed = quota - unique
    repeats = set(rng.sample(sorted(selected), repeats_needed)) if repeats_needed else set()
    n_written = 0
    j = 0
    with open_text(src) as inp, destination.open("w", encoding="utf-8") as out:
        for line in inp:
            if not line.strip():
                continue
            if j in selected:
                item = json.loads(line)
                if not isinstance(item, dict) or "id" not in item:
                    raise ValueError(f"{src}: record {j} lacks a Lhotse cut ID")
                for copy_idx in range(1 + (j in repeats)):
                    clone = dict(item)
                    # Distinct IDs are mandatory when TORGO is sampled twice.
                    clone["id"] = f"4way-{seed}-{name}-{j}-{copy_idx}"
                    if isinstance(clone.get("supervisions"), list):
                        clone["supervisions"] = [dict(s, id=f"{clone['id']}-sup-{s_idx}") for s_idx, s in enumerate(clone["supervisions"])]
                    out.write(json.dumps(clone, ensure_ascii=False, separators=(",", ":")) + "\n")
                    n_written += 1
            j += 1
    if n_written != quota:
        raise RuntimeError(f"Wrong {name} count: {n_written} vs {quota}")


def interleave(staged: dict[str, Path], quotas: dict[str, int], dest: Path, seed: int) -> None:
    rng = random.Random(f"{seed}|interleave")
    # Buffer only one line per source; weighted draws WITHOUT replacement.
    remaining = dict(quotas)
    handles = {k: v.open("r", encoding="utf-8") for k, v in staged.items()}
    tmp = dest.with_name(dest.name + ".incomplete")
    try:
        with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=3) as out:
            total_left = sum(remaining.values())
            while total_left:
                target = rng.randrange(total_left)
                upto = 0
                for name in remaining:
                    upto += remaining[name]
                    if target < upto:
                        break
                line = handles[name].readline()
                if not line:
                    raise RuntimeError(f"Unexpected end of source staging file {name}")
                out.write(line)
                remaining[name] -= 1
                total_left -= 1
        os.replace(tmp, dest)
    finally:
        for f in handles.values():
            f.close()
        if tmp.exists():
            tmp.unlink()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", default="/mnt/d/Croko_Training/manifests/experiment_c_mix_120k.jsonl.gz")
    p.add_argument("--total-cuts", type=int, default=120000)
    p.add_argument("--seed", type=int, default=42)
    for source, path in DEFAULT_SOURCES.items():
        p.add_argument("--" + source, default=path)
        p.add_argument("--weight-" + source, type=float, default=DEFAULT_WEIGHTS[source])
    p.add_argument("--max-repeat-torgo", type=int, default=2)
    p.add_argument("--force", action="store_true", help="Overwrite the output (never use on an active/resumable run!)")
    p.add_argument("--plan", action="store_true", help="Validate input counts and quotas but do not write files")
    args = p.parse_args()
    if args.total_cuts <= 0:
        p.error("--total-cuts must be positive")
    out = Path(args.out).expanduser().resolve()
    if out.suffixes[-2:] != [".jsonl", ".gz"]:
        p.error("--out must end in .jsonl.gz")
    if out.exists() and not args.force and not args.plan:
        p.error(f"Output exists; refusing to overwrite: {out}")
    paths = {k: Path(getattr(args, k)).expanduser().resolve() for k in DEFAULT_SOURCES}
    weights = {k: getattr(args, "weight_" + k) for k in paths}
    quotas = counts_by_weights(args.total_cuts, weights)
    available = {k: count_records(path) for k, path in paths.items()}
    caps = {k: (args.max_repeat_torgo if k == "torgo" else 1) for k in paths}
    for name in paths:
        if quotas[name] > available[name] * caps[name]:
            p.error(f"Quota for {name} ({quotas[name]:,}) is too high for {available[name]:,} records, repeat cap {caps[name]}")
    info = {"seed": args.seed, "total_cuts": args.total_cuts, "sources": {k: {"file": str(paths[k]), "available": available[k], "selected": quotas[k], "max_repeat": caps[k], "percentage": 100*quotas[k]/args.total_cuts} for k in paths}, "out": str(out)}
    print(json.dumps(info, indent=2), flush=True)
    if args.plan:
        return
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="mixc_", dir=out.parent) as tmpdir:
        staged = {name: Path(tmpdir) / f"{name}.jsonl" for name in paths}
        for name in paths:
            print(f"Staging {name}...", flush=True)
            stage_source(paths[name], staged[name], name=name, quota=quotas[name], available=available[name], max_repeat=caps[name], seed=args.seed)
        print("Interleaving without replacement...", flush=True)
        interleave(staged, quotas, out, args.seed)
    # Sidecar manifest is a reproducibility record; checkpoint runner hashes the manifest.
    out.with_name(out.name + ".meta.json").write_text(json.dumps(info, indent=2) + "\n", encoding="utf-8")
    print(f"OK: {out} ({out.stat().st_size/1024**2:.1f} MiB)", flush=True)

if __name__ == "__main__":
    main()
