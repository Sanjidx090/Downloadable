#!/usr/bin/env python3
"""Offline sanity tests: no CUDA, icefall, torch, or audio required."""
import gzip
import json
import random
import tempfile
from pathlib import Path
from unittest.mock import patch

from prepare_mix import counts_by_weights, stage_source, interleave
from patch_trainer import patch as patch_icefall
from run_experiment_c import choose_checkpoint


def test_all():
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        srcs = {}
        for name, n in [("sapc2",120),("aug",90),("croko",50),("torgo",7)]:
            p = root / f"{name}.jsonl.gz"
            with gzip.open(p, "wt") as f:
                for i in range(n):
                    f.write(json.dumps({"id":f"{name}-{i}", "start":0, "duration":3.0, "supervisions":[{"id":f"s-{i}", "text":"HI"}], "type":"MonoCut"}) + "\n")
            srcs[name] = p
        counts = counts_by_weights(100, {"sapc2":70,"aug":20,"croko":7,"torgo":3})
        assert counts == {"sapc2":70,"aug":20,"croko":7,"torgo":3}
        staged = {}
        for name, src in srcs.items():
            dest = root / (name + ".jsonl")
            stage_source(src,dest,name=name,quota=counts[name], available={"sapc2":120,"aug":90,"croko":50,"torgo":7}[name],max_repeat=2 if name=="torgo" else 1,seed=42)
            staged[name] = dest
        out = root / "mix.jsonl.gz"
        interleave(staged,counts,out,42)
        with gzip.open(out,"rt") as fh:
            items = [json.loads(x) for x in fh]
        assert len(items) == 100 and len({i["id"] for i in items}) == 100
        assert {name: sum(f"-{name}-" in x["id"] for x in items) for name in srcs} == counts
        # Mock a legacy SAPC2 patch-compatible run() implementation.
        trainer_src = '''def run():
    train_cuts = load_manifest_lazy("/mnt/g/SAPC2_Dataset/manifests/sapc2_cuts_train_local.jsonl.gz")
    logging.info(train_cuts)
    valid_cuts = load_manifest_lazy("/mnt/g/SAPC2_Dataset/manifests/sapc2_cuts_dev_small.jsonl.gz")
    print(valid_cuts)
'''
        patched = patch_icefall(trainer_src)
        assert patched.count("FOURWAY_TRAIN_MANIFEST") == 1
        assert patched.count("FOURWAY_VALID_MANIFEST") == 1
        import ast
        ast.parse(patched)
        # Two types of resumable checkpoint names, reject incomplete file.
        exp = root / 'exp'
        exp.mkdir()
        for name in ('epoch-1.pt','checkpoint-2000.pt'):
            import zipfile
            with zipfile.ZipFile(exp / name,'w') as z:
                z.writestr('model','a'*2_000_000)
        assert choose_checkpoint(exp,'epoch-1.pt').name == 'epoch-1.pt'
        assert choose_checkpoint(exp,'checkpoint-2000.pt').name == 'checkpoint-2000.pt'
        print('PASS quota-controlled manifest, unique IDs, patch compilation, explicit checkpoint selection')


if __name__ == '__main__':
    test_all()
