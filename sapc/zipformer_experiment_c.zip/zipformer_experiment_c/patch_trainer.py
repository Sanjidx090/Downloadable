#!/usr/bin/env python3
"""Safely patch the LOCAL causal Icefall finetune.py to use Experiment C manifests.

This tool intentionally refuses to guess if it cannot identify the exact SAPC2
train/dev CutSet load statements in your existing customized trainer.
"""
import argparse
import ast
from pathlib import Path


def choose_assignment(root: ast.AST, var: str) -> ast.Assign:
    found = []
    for node in ast.walk(root):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if not any(isinstance(t, ast.Name) and t.id == var for t in targets):
            continue
        call = node.value
        if not isinstance(call, ast.Call):
            continue
        func = call.func
        if not isinstance(func, ast.Name) or func.id != "load_manifest_lazy":
            continue
        if not call.args or not isinstance(call.args[0], ast.Constant):
            continue
        if "sapc2" not in str(call.args[0].value).lower():
            continue
        found.append(node)
    if len(found) != 1:
        raise RuntimeError(f"Expected exactly one direct SAPC2 load_manifest_lazy(...) assignment to {var}; found {len(found)}. Please upload your source finetune_original.py so it can be patched safely.")
    return found[0]


def patch(src: str) -> str:
    root = ast.parse(src)
    if "FOURWAY_TRAIN_MANIFEST" in src or "FOURWAY_VALID_MANIFEST" in src:
        raise RuntimeError("Trainer appears already patched: use your unmodified finetune.py as input")
    train = choose_assignment(root, "train_cuts")
    valid = choose_assignment(root, "valid_cuts")
    lines = src.splitlines(keepends=True)
    changes = []
    for node, var, env in ((train, "train_cuts", "FOURWAY_TRAIN_MANIFEST"), (valid, "valid_cuts", "FOURWAY_VALID_MANIFEST")):
        if node.end_lineno != node.lineno:
            raise RuntimeError(f"{var} assignment spans multiple lines; refusing to auto-patch")
        line = lines[node.lineno-1]
        indent = line[:len(line) - len(line.lstrip())]
        newline = (
            f"{indent}import os as _fourway_os\n"
            f"{indent}from lhotse import load_manifest_lazy as _fourway_load\n"
            f"{indent}{var} = _fourway_load(_fourway_os.environ['{env}'])\n"
        )
        changes.append((node.lineno-1, newline))
    for index, replacement in sorted(changes, reverse=True):
        lines[index] = replacement
    result = "".join(lines)
    ast.parse(result)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", default="~/icefall/egs/librispeech/ASR/zipformer/finetune.py")
    p.add_argument("--output", default="~/icefall/egs/librispeech/ASR/zipformer/finetune_4way.py")
    args = p.parse_args()
    src = Path(args.source).expanduser().resolve()
    dst = Path(args.output).expanduser().resolve()
    if src == dst:
        p.error("Output must not overwrite original trainer")
    if not src.is_file():
        p.error(f"Original trainer missing: {src}")
    if dst.exists():
        p.error(f"Output already exists; refusing to overwrite: {dst}")
    data = patch(src.read_text(encoding="utf-8"))
    dst.write_text(data, encoding="utf-8")
    print(f"PATCH SUCCESS: {dst}")
    print("Your original trainer was NOT modified.")
    print("Changed: SAPC2 train + validation manifest loaders only.")
    print("All other Zipformer, logging, checkpoint, and sampler code remains unchanged.")

if __name__ == "__main__":
    main()
