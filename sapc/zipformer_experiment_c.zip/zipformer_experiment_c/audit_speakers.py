#!/usr/bin/env python3
"""Check that SAPC2 original and augmentation do not contain SAPC2 Dev speaker IDs.

This audit checks IDs in Lhotse supervisions, not hidden audio identities or
underlying recording lineage. Verify augmented recording provenance separately.
"""
import argparse
import gzip
import json
from pathlib import Path
from prepare_mix import DEFAULT_SOURCES


def get_speakers(path):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    op = gzip.open if str(path).endswith(".gz") else open
    speakers = set()
    n=0
    with op(path,'rt',encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            data=json.loads(line)
            for sup in data.get('supervisions',[]):
                sp=sup.get('speaker')
                if sp not in (None, ''):
                    speakers.add(str(sp))
            n += 1
    return speakers,n


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dev',default='/mnt/g/SAPC2_Dataset/manifests/sapc2_cuts_dev.jsonl.gz')
    p.add_argument('--train',default=DEFAULT_SOURCES['sapc2'])
    p.add_argument('--aug',default=DEFAULT_SOURCES['aug'])
    args=p.parse_args()
    dev,nd=get_speakers(args.dev)
    if not dev:
        raise SystemExit('ERROR: Dev manifest has no speaker metadata; cannot perform audit')
    print(f'Dev: {nd:,} cuts, {len(dev)} speaker IDs')
    failures=0
    for name,path in [('SAPC2 train',args.train),('SAPC2 augmentation',args.aug)]:
        speakers,n=get_speakers(path)
        common=dev & speakers
        print(f'{name}: {n:,} cuts, {len(speakers)} speaker IDs, dev IDs intersect={len(common)}')
        if common:
            print('Examples of shared dev speakers:',sorted(common)[:10]);failures+=1
    if failures:
        raise SystemExit('FAIL: DEV speaker collision detected. Do not train until fixed.')
    print('PASS: No DEV speaker ID collisions in these two SAPC2 training sources.')
    print('LIMITATION: augmentation source lineage and external TORGO/Croko text were not checked here.')

if __name__=='__main__':
    main()
